/* Studio Field Notes: editorial asymmetry, cream paper, ink green, clay orange, tactile studio cues. */
import { useEffect, useState, type Dispatch, type SetStateAction } from "react";
import {
  ArrowDownRight,
  ArrowRight,
  ArrowUpRight,
  BookOpen,
  Check,
  CircleDot,
  Clock3,
  Hammer,
  Instagram,
  Mail,
  MapPin,
  Menu,
  Palette,
  PenTool,
  ShieldCheck,
  Sparkles,
  X,
} from "lucide-react";

const GOOGLE_FORM_URL =
  "https://docs.google.com/forms/d/e/1FAIpQLSe0NEVKpL8CF9sayROozVH7mvE3laXc2FEN3WHOTSym7EZf1g/viewform?usp=publish-editor";

const processSteps = [
  {
    number: "01",
    title: "介紹你的創作",
    body: "分享支撐你作品的材料、技術與創作故事。",
    icon: PenTool,
  },
  {
    number: "02",
    title: "我們尋找合適配對",
    body: "我們會了解你的經驗、教學方式、課堂形式及授課地點。",
    icon: BookOpen,
  },
  {
    number: "03",
    title: "為新學員留出空間",
    body: "如果收到合適的查詢，我們會連同背景一起聯絡，而不是轉發一個陌生名單。",
    icon: Sparkles,
  },
];

const craftAreas = [
  { label: "Ceramics", detail: "Clay · glaze · handbuilding", icon: CircleDot },
  { label: "Wood & carving", detail: "Joinery · relief · tools", icon: Hammer },
  { label: "Jewellery", detail: "Metal · wax · adornment", icon: Sparkles },
  { label: "Textile & fibre", detail: "Thread · stitch · surface", icon: Palette },
];

const skillGroups = [
  { level: "初階學員", items: ["材料認識與安全入門", "基本工具使用", "簡單形體與構圖", "基礎色彩、紋理或表面處理"] },
  { level: "中階學員", items: ["技術深化與作品完成", "個人風格與創作方向", "系列作品規劃", "材料實驗與問題修正"] },
  { level: "進階學員", items: ["作品集與專題指導", "專業技術與工藝流程", "展覽／發表作品準備", "個人創作研究與批評"] },
];

const lessonFormats = ["私人課", "小組課堂", "工作坊", "共享工作室", "到訪教學", "網上理論／設計指導"];
const lessonLocations = ["自己的工作室", "租用工作室", "共享藝術空間", "指定場地", "學員家中", "網上授課"];
const districts = ["香港島", "九龍", "新界東", "新界西", "只接受網上"];
const stationGroups = [
  { district: "香港島", stations: ["堅尼地城", "香港大學", "西營盤", "上環", "中環", "金鐘", "灣仔", "銅鑼灣", "天后", "北角", "鰂魚涌", "太古", "西灣河", "筲箕灣", "柴灣"] },
  { district: "九龍", stations: ["佐敦", "尖沙咀", "紅磡", "何文田", "黃埔", "油麻地", "旺角", "太子", "石硤尾", "九龍塘", "樂富", "黃大仙", "鑽石山", "彩虹", "九龍灣", "牛頭角", "觀塘", "藍田", "油塘"] },
  { district: "新界東", stations: ["大圍", "沙田", "第一城", "恒安", "馬鞍山", "烏溪沙", "大學", "大埔墟", "太和", "粉嶺", "上水"] },
  { district: "新界西", stations: ["荃灣", "大窩口", "葵興", "葵芳", "荔景", "青衣", "欣澳", "東涌", "兆康", "屯門", "元朗", "朗屏", "天水圍", "錦上路", "落馬洲"] },
];

const navItems = [
  { label: "理念", href: "#idea" },
  { label: "運作方式", href: "#process" },
  { label: "申請", href: "#apply" },
];

export default function Home() {
  const [menuOpen, setMenuOpen] = useState(false);
  const [selectedSkills, setSelectedSkills] = useState<string[]>([]);
  const [selectedFormats, setSelectedFormats] = useState<string[]>([]);
  const [selectedLocations, setSelectedLocations] = useState<string[]>([]);
  const [selectedDistricts, setSelectedDistricts] = useState<string[]>([]);
  const [selectedStations, setSelectedStations] = useState<string[]>([]);
  const [otherDetails, setOtherDetails] = useState("");
  const [contactDetails, setContactDetails] = useState({ name: "", email: "", phone: "", portfolio: "" });

  const toggleValue = (value: string, setter: Dispatch<SetStateAction<string[]>>) => {
    setter((current) => current.includes(value) ? current.filter((item) => item !== value) : [...current, value]);
  };

  useEffect(() => {
    const items = document.querySelectorAll<HTMLElement>(".reveal");
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.classList.add("is-visible");
            observer.unobserve(entry.target);
          }
        });
      },
      { threshold: 0.12 },
    );
    items.forEach((item) => observer.observe(item));
    return () => observer.disconnect();
  }, []);

  const closeMenu = () => setMenuOpen(false);

  return (
    <div className="site-shell">
      <div className="top-note">
        <span>Studio Field Notes／招募中</span>
        <span>給獨立創作者與耐心的導師</span>
      </div>

      <header className="masthead">
        <a className="brand" href="#top" aria-label="Studio Field Notes 首頁">
          <img className="brand-mark-image" src="/manus-storage/studio-field-notes-mark_e6cf1659.png" alt="" aria-hidden="true" />
          <span className="brand-lockup">
            <strong>Studio</strong>
            <em>Field Notes</em>
          </span>
        </a>

        <nav className={`desktop-nav ${menuOpen ? "mobile-open" : ""}`} aria-label="主要導航">
          {navItems.map((item) => (
            <a key={item.href} href={item.href} onClick={closeMenu}>
              {item.label}
            </a>
          ))}
          <a className="nav-cta" href="#apply" onClick={closeMenu}>
            加入導師網絡 <ArrowUpRight size={15} strokeWidth={1.8} />
          </a>
        </nav>

        <button
          className="menu-toggle"
          type="button"
          aria-label={menuOpen ? "Close menu" : "Open menu"}
          aria-expanded={menuOpen}
          onClick={() => setMenuOpen((open) => !open)}
        >
          {menuOpen ? <X size={22} /> : <Menu size={22} />}
        </button>
      </header>

      <main id="top">
        <section className="hero section-pad">
          <div className="hero-copy reveal">
            <div className="eyebrow"><span className="eyebrow-line" /> 工作室筆記／01</div>
            <h1>合適的創作導師，會為你的觀看方式留出空間。</h1>
            <p className="hero-lede">
              給想學習工藝的人一個踏實的起點，也給準備分享創作方法的創作者一個合適的入口。
            </p>
            <div className="hero-actions">
              <a className="button button-primary" href="#apply">
                申請成為導師 <ArrowRight size={17} />
              </a>
              <a className="text-link" href="#process">
                先了解簡要流程 <ArrowDownRight size={16} />
              </a>
            </div>
            <div className="hero-footnote">
              <ShieldCheck size={15} /> 不承諾配對結果，只提供一個更清晰的開始。
            </div>
          </div>

          <div className="hero-visual reveal reveal-delay-1">
            <div className="image-frame hero-frame">
              <img
                src="/manus-storage/studio-field-notes-hero_b83cdf06.jpg"
                alt="陽光照耀的工藝工作枱，上面放有陶器、亞麻布和速寫本"
              />
              <div className="image-caption">
                <span>工作室影像／001</span>
                <span>讓創作時間被看見</span>
              </div>
            </div>
            <div className="side-note side-note-top">為<br /><strong>慢工與細節</strong>留一席</div>
            <div className="side-note side-note-bottom"><span>香港／2026</span><span>開放給工藝創作</span></div>
          </div>
        </section>

        <section className="manifesto section-pad" id="idea">
          <div className="manifesto-index reveal">02<br /><span>為何建立</span></div>
          <div className="manifesto-main reveal reveal-delay-1">
            <p className="eyebrow">把理念說得簡單一點</p>
            <h2>好的教學不是表演，而是一個邀請，讓你再看近一點。</h2>
            <div className="manifesto-grid">
              <p>
                我們正在為成人學員建立一個小而細緻的藝術與工藝導師網絡。不是嘈雜的名錄，也不是比拼低價的市場，而是一張重視合適細節的工作枱。
              </p>
              <p>
                你的創作可能在共享工作室、家中的餐桌，或一次耐心拆解失敗嘗試的講解中發生。我們想了解的，正是這些細節。
              </p>
            </div>
          </div>
          <div className="stamp reveal reveal-delay-2">
            <span>看</span><span>近一點</span><span>動手做</span>
          </div>
        </section>

        <section className="process section-pad" id="process">
          <div className="section-heading reveal">
            <div className="eyebrow"><span className="eyebrow-line" /> 流程／03</div>
            <h2>步驟清楚，由人細閱。</h2>
            <p>一份表格、一次仔細審閱，還有在合適時機展開的對話。</p>
          </div>
          <div className="process-list">
            {processSteps.map((step, index) => {
              const Icon = step.icon;
              return (
                <article className={`process-item reveal reveal-delay-${index + 1}`} key={step.number}>
                  <div className="process-number">{step.number}</div>
                  <div className="process-icon"><Icon size={20} strokeWidth={1.5} /></div>
                  <div className="process-copy">
                    <h3>{step.title}</h3>
                    <p>{step.body}</p>
                  </div>
                  <ArrowUpRight className="process-arrow" size={20} strokeWidth={1.4} />
                </article>
              );
            })}
          </div>
        </section>

        <section className="craft-section section-pad">
          <div className="craft-image reveal">
            <img src="https://images.unsplash.com/photo-1578749556568-bc2c40e68b61?auto=format&fit=crop&w=1200&q=85" alt="雙手正在塑造小型陶器" />
            <div className="image-caption light-caption"><span>雙手正在創作</span><span>不必過度修飾</span></div>
          </div>
          <div className="craft-copy reveal reveal-delay-1">
            <div className="eyebrow">可以分享甚麼／04</div>
            <h2>帶來你最熟悉的材料。</h2>
            <p>我們歡迎專家、願意分享的創作者，以及把「不如換個方法試試」作為第一句教學的人。</p>
            <div className="craft-list">
              {craftAreas.map((area) => {
                const Icon = area.icon;
                return (
                  <div className="craft-row" key={area.label}>
                    <Icon size={17} strokeWidth={1.5} />
                    <span><strong>{area.label}</strong><small>{area.detail}</small></span>
                    <ArrowRight size={15} />
                  </div>
                );
              })}
            </div>
            <a className="text-link text-link-dark" href="#apply">查看完整申請表 <ArrowRight size={16} /></a>
          </div>
        </section>

        <section className="quote-section section-pad">
          <div className="quote-mark">“</div>
          <blockquote className="reveal">
            最好的引導，會讓你留下更多問題——而且是最好的那種。
          </blockquote>
          <div className="quote-meta reveal reveal-delay-1"><span /> 工作枱上的一則筆記／不是承諾</div>
        </section>

        <section className="apply-section section-pad" id="apply">
          <div className="apply-intro reveal">
            <div className="eyebrow"><span className="eyebrow-line" /> 申請工作枱／05</div>
            <h2>告訴我們你喜歡創作甚麼。</h2>
            <p>我們會仔細閱讀、保護你的資料，並在出現合適的下一步時與你聯絡。</p>
            <div className="apply-meta">
              <span><Clock3 size={15} /> 6–8 min</span>
              <span><MapPin size={15} /> 香港及網上</span>
            </div>
          </div>
          <div className="form-card reveal reveal-delay-1">
            <div className="form-card-top"><span>Studio Field Notes</span><span>表格／01</span></div>
            <div className="form-icon"><PenTool size={22} strokeWidth={1.4} /></div>
            <h3>成人工藝藝術導師申請表</h3>
            <p>請介紹你的創作、可教授的技術，以及你希望遇上的學員類型。</p>
            <div className="form-checks form-preview">
              <div className="contact-fields">
                <label className="form-field"><span className="form-label">姓名／工作室名稱</span><input type="text" value={contactDetails.name} onChange={(event) => setContactDetails({ ...contactDetails, name: event.target.value })} placeholder="你的姓名或工作室名稱" /></label>
                <label className="form-field"><span className="form-label">電郵地址</span><input type="email" value={contactDetails.email} onChange={(event) => setContactDetails({ ...contactDetails, email: event.target.value })} placeholder="name@example.com" /></label>
                <label className="form-field"><span className="form-label">WhatsApp／電話號碼</span><input type="tel" value={contactDetails.phone} onChange={(event) => setContactDetails({ ...contactDetails, phone: event.target.value })} placeholder="例如 9123 4567" /></label>
                <label className="form-field"><span className="form-label">作品集／社交媒體／工作室網站</span><input type="url" value={contactDetails.portfolio} onChange={(event) => setContactDetails({ ...contactDetails, portfolio: event.target.value })} placeholder="https://" /></label>
              </div>
              <div className="form-field">
                <span className="form-label">你可教授哪些課程或技術？</span>
                <small>請按學員程度選擇適合內容</small>
                {skillGroups.map((group) => (
                  <div className="checkbox-group" key={group.level}>
                    <strong>{group.level}</strong>
                    {group.items.map((item) => (
                      <label className="checkbox-option" key={item}>
                        <input type="checkbox" checked={selectedSkills.includes(item)} onChange={() => toggleValue(item, setSelectedSkills)} />
                        <span>{item}</span>
                      </label>
                    ))}
                  </div>
                ))}
              </div>
              <div className="form-field">
                <span className="form-label">你可以提供哪些課堂形式及授課地點？</span>
                <small>可選私人課、工作坊、共享工作室、到訪或網上</small>
                <div className="checkbox-grid">
                  {lessonFormats.map((item) => <label className="checkbox-option" key={item}><input type="checkbox" checked={selectedFormats.includes(item)} onChange={() => toggleValue(item, setSelectedFormats)} /><span>{item}</span></label>)}
                </div>
                <div className="checkbox-grid">
                  {lessonLocations.map((item) => <label className="checkbox-option" key={item}><input type="checkbox" checked={selectedLocations.includes(item)} onChange={() => toggleValue(item, setSelectedLocations)} /><span>{item}</span></label>)}
                </div>
              </div>
              <div className="form-field">
                <span className="form-label">授課地區及港鐵站</span>
                <small>請選擇可授課地區，再選擇附近港鐵站</small>
                <div className="checkbox-grid compact-grid">
                  {districts.map((item) => <label className="checkbox-option" key={item}><input type="checkbox" checked={selectedDistricts.includes(item)} onChange={() => toggleValue(item, setSelectedDistricts)} /><span>{item}</span></label>)}
                </div>
                <div className="station-groups">
                  {stationGroups.map((group) => (
                    <div className="station-group" key={group.district}>
                      <strong>{group.district}港鐵站</strong>
                      <div className="checkbox-grid compact-grid">
                        {group.stations.map((item) => <label className="checkbox-option" key={item}><input type="checkbox" checked={selectedStations.includes(item)} onChange={() => toggleValue(item, setSelectedStations)} /><span>{item}</span></label>)}
                      </div>
                    </div>
                  ))}
                </div>
              </div>
              <label className="form-field other-field">
                <span className="form-label">其他／補充說明</span>
                <textarea value={otherDetails} onChange={(event) => setOtherDetails(event.target.value)} placeholder="例如其他地區、港鐵站或特殊場地安排" rows={3} />
              </label>
              <span className="form-hint"><Check size={14} /> 可先在此整理選項，正式提交會在完整 Google Form 完成。</span>
            </div>
            <a className="button button-orange" href={GOOGLE_FORM_URL} target="_blank" rel="noreferrer">
              開啟完整申請表 <ArrowUpRight size={17} />
            </a>
            <p className="privacy-note"><ShieldCheck size={14} /> 你提交的資料只會用於初步審閱及相關介紹。</p>
          </div>
        </section>
      </main>

      <footer className="footer section-pad">
        <div className="footer-brand"><img className="brand-mark-image" src="/manus-storage/studio-field-notes-mark_e6cf1659.png" alt="" aria-hidden="true" /><span>Studio<br /><i>Field Notes</i></span></div>
        <div className="footer-copy"><p>一張放置創作、耐心教學與下一個合適配對的小工作枱。</p><span>© 2026 Studio Field Notes</span></div>
        <div className="footer-links"><a href="mailto:hello@studiofieldnotes.example"><Mail size={15} /> 電郵</a><a href="#top"><ArrowUpRight size={15} /> 返回頂部</a><a href="https://instagram.com" target="_blank" rel="noreferrer"><Instagram size={15} /> Instagram</a></div>
      </footer>
    </div>
  );
}
